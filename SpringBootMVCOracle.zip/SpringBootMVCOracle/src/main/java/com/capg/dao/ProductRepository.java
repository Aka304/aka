package com.capg.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.capg.beans.Product;
@Repository
public interface ProductRepository extends JpaRepository<Product, Integer> {

				/*@Query("from Employee where salary=?1 order by ename")
                 List<Employee>  findBySalary(double salary);
                 
                 
                 @Query("from Employee where salary between 4000 and 15000")
                 List<Employee> findByRange();*/
                 
                 
                 
}
