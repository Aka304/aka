package com.capg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.beans.Product;
import com.capg.dao.ProductRepository;

@Service
public class ProductServiceImp implements ProductService {
	@Autowired
	ProductRepository repo;

	@Override
	public Product getProductById(int eid) {

		return repo.findById(eid).orElse(new Product());
	}

	@Override
	public List<Product> getAllProduct() {
		// TODO Auto-generated method stub
		return repo.findAll();

	}

	@Override
	public void deleteProductById(int eid) {

		repo.deleteById(eid);

	}

	@Override
	public Product addProduct(Product product) {

		return repo.save(product);
	}

	@Override
	public Product updateProductById(Product pid) {
		// TODO Auto-generated method stub
		return repo.save(pid);
	}

}
