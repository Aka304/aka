package com.capg.service;

import java.util.List;

import com.capg.beans.Product;

public interface ProductService {

	public Product getProductById(int eid);
	public List<Product> getAllProduct();
	
	public void deleteProductById(int eid);

	public Product addProduct(Product emp);
	
	public Product updateProductById(Product pid);
	
	/*public List<Product> getEmployeeBySalary(double salary);
	
	public List<Product> getEmployeesByRange();*/
}
