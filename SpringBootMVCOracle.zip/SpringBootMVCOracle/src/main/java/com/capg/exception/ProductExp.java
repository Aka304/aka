package com.capg.exception;

public class ProductExp extends Exception 

{


}
