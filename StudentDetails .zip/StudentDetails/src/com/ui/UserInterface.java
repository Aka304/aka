package com.ui;

import java.util.Scanner;

import com.bean.Student;
import com.utility.College;

public class UserInterface {

	public static void main(String a[]) {
		int yourvar1 = 0;
		System.out.println("Enter the number of student details");
		Scanner yourvar = new Scanner(System.in);
		College you = new College();
		yourvar1 = Integer.parseInt(yourvar.nextLine());
		System.out.println("Enter the student details");
		
		for (int i = 0; i < yourvar1; i++) {
			String details = yourvar.nextLine();
			Student student = new Student();
			student.parseData(details);
			you.addStudent(student);
		}
		
		
		System.out.println("Enter the grade");
		String your4 = yourvar.nextLine();
		System.out.println("Count:" + you.countBasedOnGrade(your4));
		yourvar.close();
	}

}
