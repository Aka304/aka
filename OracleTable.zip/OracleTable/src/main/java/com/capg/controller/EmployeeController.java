package com.capg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capg.beans.Employee;
import com.capg.service.IEmployeeService;

import net.bytebuddy.implementation.bind.annotation.AllArguments;

@RestController
public class EmployeeController {

	@Autowired
	IEmployeeService service;

	// GETTING EMPLOYEES DETAILS BY ID
	@GetMapping(path = "/employee/{eid}", produces = { "application/json" })

	public Employee getEmployeeById(@PathVariable int eid) {

		Employee emp = service.getEmployeeId(eid);

		return emp;
	}

	// DISPLAYING ALL EMPLOYEES DETAILS
	@GetMapping(path = "/getEmployee", produces = "application/xml")
	public List<Employee> getAllEmployee() {
		return service.getAllEmployee();

	}

	// DELETING EMPLOYEE DETAILS BY ID
	@DeleteMapping(path = "/employee/{eid}", produces = { "application/json" })
	public void delete(@PathVariable int eid) {
		service.delete(eid);
	}

	// INSERTING NEW EMPLOYEE DETAILS
	@PostMapping(path = "/employee", consumes = "application/json")
	public Employee insert(@RequestBody Employee emp) {

		return service.insert(emp);
		// return emp;

	}

	// UPDATING EMPLOYEE DETAILS
	@PutMapping(path = "/employee", consumes = "application/json")
	public Employee update(@RequestBody Employee emp) {
		return service.update(emp);

	}

	// GETTING EMPLOYEE DETAILS BY SALARY
	@GetMapping(path = "/employee1/{salary}", produces = { "application/json" })

	public List<Employee> getEmployeeBySalary(@PathVariable double salary) {

		List<Employee> list = service.getEmployeeBySalary(salary);

		return list;
	}

	// GETTING EMPLOYEE DETAILS BY RANGE
	@GetMapping(path = "/employeesalary")

	public List<Employee> getEmployeeByRange() {

		List<Employee> list = service.getEmployeeByRange();

		return list;
	}

}
