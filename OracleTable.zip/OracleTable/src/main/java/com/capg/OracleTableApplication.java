package com.capg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OracleTableApplication {

	public static void main(String[] args) {
		SpringApplication.run(OracleTableApplication.class, args);
	}

}
