package com.capg.service;

import java.util.*;

import com.capg.beans.Employee;

public interface IEmployeeService {

	public Employee getEmployeeId(int eid);

	public List<Employee> getAllEmployee();

	public void delete(int eid);

	public Employee insert(Employee emp);

	public Employee update(Employee emp);

	public List<Employee> getEmployeeBySalary(double salary);

	public List<Employee> getEmployeeByRange();

}
