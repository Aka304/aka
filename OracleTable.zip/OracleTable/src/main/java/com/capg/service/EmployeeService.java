package com.capg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.beans.Employee;
import com.capg.dao.EmployeeRepository;

@Service
public class EmployeeService implements IEmployeeService {
	@Autowired
	EmployeeRepository repo;

	@Override
	public Employee getEmployeeId(int eid) {
		return repo.findById(eid).orElse(new Employee());
	}

	@Override
	public List<Employee> getAllEmployee() {
		// TODO Auto-generated method stub
		// Iterable it= repo.findAll();

		return repo.findAll();
	}

	/*
	 * @Override public Employee update() { // TODO Auto-generated method stub
	 * return repo.; }
	 */

	@Override
	public void delete(int eid) {
		// TODO Auto-generated method stub
		repo.deleteById(eid);
	}

	@Override
	public Employee insert(Employee emp) {
		return repo.save(emp);

	}
	@Override
	public Employee update(Employee emp) {
		return repo.save(emp);
	}

	@Override
	public List<Employee> getEmployeeBySalary(double salary) {
		// TODO Auto-generated method stub
		return repo.findBySalary(salary);
	}

	@Override
	public List<Employee> getEmployeeByRange() {
		// TODO Auto-generated method stub
		return repo.findByRange();
	}

}