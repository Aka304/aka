package com.capg.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.capg.beans.Employee;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Integer> {
	@Query("from Employee where salary=?1 order by ename")
	List<Employee> findBySalary(double salary);

	@Query("from Employee where salary between 7000 and 50000")
	List<Employee> findByRange();
}
