package com.capg.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.Repository;

import com.capg.beans.Trainee;

@org.springframework.stereotype.Repository
public interface DAORepository extends CrudRepository<Trainee, Integer> {

}
