package com.capg;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Controller

public class TraineeController {
	@GetMapping("/")
	public String form1() {
		return "Form1";
	}
	@GetMapping("/display")
	public String TMS() {
		return "tableMng";
	}
	@GetMapping("/AddTrainee")
	public String AddTrainee() {
		return "AddTrainee";
	}

}
