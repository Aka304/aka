import { Injectable } from '@angular/core';
import { Employee } from './employee';
@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  static employeeArray: Employee[]=[];
  constructor() { }

 addEmployeeService(empForm){
  let employeeObj = new Employee();
  employeeObj.id = empForm.id;
  employeeObj.name = empForm.name;
  employeeObj.email = empForm.email;
  employeeObj.phone = empForm.phone;
  EmployeeService.employeeArray.push(employeeObj);
  alert(EmployeeService.employeeArray[0].id);
 }
 listEmployeeService() {
  return EmployeeService.employeeArray;
}
deleteEmployee(i) {
  EmployeeService.employeeArray.splice(i,1);
}
}
