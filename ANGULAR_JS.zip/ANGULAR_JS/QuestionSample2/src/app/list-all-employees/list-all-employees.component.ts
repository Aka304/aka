import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Employee } from '../employee';

@Component({
  selector: 'app-list-all-employees',
  templateUrl: './list-all-employees.component.html',
  styleUrls: ['./list-all-employees.component.css']
})
export class ListAllEmployeesComponent implements OnInit {
  employeeServiceObj: EmployeeService = new EmployeeService();
  empList: Employee[]=[];
  constructor() { }

  ngOnInit() {
    this.empList = this.employeeServiceObj.listEmployeeService();
  }
  deleteEmployee(i){
    alert("DELETED");
    this.employeeServiceObj.deleteEmployee(i);
  }

}
