import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ProductList } from '../ProductList';
import { ProductListService } from '../product-list.service';
@Component({
  selector: 'app-search-form',
  templateUrl: './search-form.component.html',
  styleUrls: ['./search-form.component.css']
})
export class SearchFormComponent implements OnInit {

  constructor(private route:ProductListService) {
   }
   SearchList:ProductList[];
   List:ProductList[]=[];

  ngOnInit() {
    this.getAllProductList();
  }
  getAllProductList(){
    this.route.getAllProductList().subscribe(db=> this.SearchList=db);
  }

  SearchForm(myForm1){
    let j=0;
    for(let i=0;i<this.SearchList.length;i++){
      if(this.SearchList[i].name==myForm1.value.name){
      //  this.empList.splice(i,1);
      this.List[j]=this.SearchList[i];
      j++
}
}
  }
}
