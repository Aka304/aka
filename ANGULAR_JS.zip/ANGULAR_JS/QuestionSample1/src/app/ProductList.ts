
export interface ProductList{
id:number;
name:string;
salary:number;
category:string;
}