import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import{Routes,RouterModule, RoutesRecognized} from '@angular/router';
import {HttpClientModule,HttpClient} from'@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ProductListComponent } from './product-list/product-list.component';
import { SearchFormComponent } from './search-form/search-form.component';
import{FormsModule} from'@angular/forms';
import { ProductListService } from './product-list.service';
const routes:Routes=[
  {path:'search',component: SearchFormComponent},
  {path:'ProductList',component:ProductListComponent}
];
@NgModule({
  declarations: [
    AppComponent,
    ProductListComponent,
    SearchFormComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot(routes)
  
  ],
  providers: [ProductListService],
  bootstrap: [AppComponent]
})
export class AppModule { }
