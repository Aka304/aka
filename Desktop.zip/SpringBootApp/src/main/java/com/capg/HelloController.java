package com.capg;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
//used to display the message i.e work as @responsebody+@controller
public class HelloController {

	@RequestMapping(value="/", method=RequestMethod.GET)
	//@RequestMapping("/display")
	public String display() {
	
	return "display";
	
}
}
