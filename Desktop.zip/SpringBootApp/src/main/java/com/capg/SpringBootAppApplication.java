package com.capg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class SpringBootAppApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext context = SpringApplication.run(SpringBootAppApplication.class, args);
		Employee emp = context.getBean(Employee.class);

		emp.setEid(100);
		emp.setEname("AKASH");
		emp.setSalary(50000);
		System.out.println(emp);
		// System.out.println(emp.getEid()+"\n"+emp.getEname()+"\n"+emp.getSalary());
		//System.out.println();
	}

}
//***********IMPORTANT NOTES*********************

// If error occurs that tomcat server using port 8080 then we need to change it
// in the properties file in src/main/resources = application.porperties eg= server.port=9090

// we can also change it in xml fle in apche folder in conf file

//scanning of component is done by @springBootApplication

// for text alignment in code i.e whole code alignment we need to use=  ctrl+shift+f

//If we want to create project in eclipse then we can go to start.spring.io then create project there
// after that download and use it in eclipse for that we also need a small plugin in eclipse
