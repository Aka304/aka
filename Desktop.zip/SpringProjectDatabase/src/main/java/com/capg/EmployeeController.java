package com.capg;

import org.apache.catalina.startup.ClassLoaderFactory.Repository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Controller
public class EmployeeController {
	@Autowired
	DAORepository repo;
	
	@GetMapping("/")
	public String form() {
		return "NewFile";
	}
	/*@GetMapping("/display")
	public String display(Employee emp, Model model) {
		
		model.addAttribute("emp",emp);
		//repo.save(emp);
		
		return "display";
		
	}*/
	@GetMapping("/display")
	public Employee save(Employee emp) {
		return repo.save(emp);
		
		
	}
}
