package com.capg;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.jboss.logging.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Controller
public class DisplayController {
	@Autowired
	Employee emp;
@RequestMapping("/")
public String form() {
	return "form1";
}
@RequestMapping("/display")
public String display(HttpServletRequest request,HttpServletResponse response,HttpSession session) {
//public String display(@RequestParam("eid") int eid,@RequestParam("ename") String ename, @RequestParam("salary") double salary, Model m) {
	int eid = Integer.parseInt(request.getParameter("eid"));//we need to take eid from the form i.e why we are converting string value of form into integer
	String ename=request.getParameter("ename");
	double salary=Double.parseDouble(request.getParameter("salary"));
	emp.setEid(eid);
	emp.setEname(ename);
	emp.setSalary(salary);
	session.setAttribute("emp", emp);
	return "display";
}

}
