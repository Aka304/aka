package com.capg.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
@Entity
public class Account {
	
	
private String name;
@Id
private int accntNo;
private String mobileNo;
private double balance;
@Override
public String toString() {
	return "Account [name=" + name + ", accntNo=" + accntNo + ", mobileNo=" + mobileNo + ", balance=" + balance + "]";
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getAccntNo() {
	return accntNo;
}
public void setAccntNo(int accntNo) {
	this.accntNo = accntNo;
}
public String getMobileNo() {
	return mobileNo;
}
public void setMobileNo(String mobileNo) {
	this.mobileNo = mobileNo;
}
public double getBalance() {
	return balance;
}
public void setBalance(double balance) {
	this.balance = balance;
}
}
