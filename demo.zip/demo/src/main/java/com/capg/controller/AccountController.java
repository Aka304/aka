package com.capg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capg.bean.Account;
import com.capg.service.AccountService;
@CrossOrigin(origins="http://localhost:4200")
@RestController

public class AccountController {
	
	@Autowired
	AccountService accountService;
@RequestMapping(value="/create",method=RequestMethod.POST)
public Account addAccount(@RequestBody Account accnt) {
	
	return accountService.getAccountDetails(accnt);
	
}

@RequestMapping("/showBalance/{accntNo}")
public double showBalance(@PathVariable int accntNo) {
//	System.out.println(accntNo);
	return accountService.showBalance1(accntNo);
	
}
@RequestMapping("deposit/{accntNo}/{amount}")
public double depositAmount(@PathVariable int accntNo,@PathVariable int amount) {
	return accountService.depositAmount1(accntNo, amount);
	
	
}
@RequestMapping("withdraw/{accntNo}/{amount}")
public double withdrawAmount(@PathVariable int accntNo,@PathVariable int amount) {
	return accountService.withdrawAmount1(accntNo, amount);
	
	
}

@RequestMapping("fundTransfer/{}/{}")
public  Account cashTransfer(@PathVariable int source,@PathVariable int destination,@PathVariable double money) {
	
	return accountService.cashTransfer(source, destination, money);
}



}
