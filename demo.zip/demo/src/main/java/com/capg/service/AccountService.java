package com.capg.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.bean.Account;
import com.capg.dao.AccountDAO;

@Service
public class AccountService {

	@Autowired
	AccountDAO AccntDao;

	public Account getAccountDetails(Account account) {

		return AccntDao.save(account);

	}

	public double showBalance1(int accntNo) {

		Account accnt = AccntDao.findById(accntNo).get();
		return accnt.getBalance();
	}

	public double depositAmount1(int accntNo, double amount) {

		Optional<Account> optional = AccntDao.findById(accntNo);
		Account dp = optional.get();
		dp.setBalance(optional.get().getBalance() + amount);
		AccntDao.save(dp);
		return AccntDao.findById(accntNo).get().getBalance();

	}

	public double withdrawAmount1(int accntNo, double amount) {

		Optional<Account> optional = AccntDao.findById(accntNo);
		Account dp = optional.get();
		dp.setBalance(optional.get().getBalance() - amount);
		AccntDao.save(dp);
		return AccntDao.findById(accntNo).get().getBalance();

	}

	public Account cashTransfer(int source, int destination, double money) {

		Optional<Account> optional1 = AccntDao.findById(source);
		Optional<Account> optional2 = AccntDao.findById(destination);

		Account deposit = optional1.get();
		Account credit = optional2.get();
		deposit.setBalance(deposit.getBalance() - money);
		credit.setBalance(deposit.getBalance() + money);
		AccntDao.save(deposit);
		AccntDao.save(credit);
		return AccntDao.findById(source).get();

	}

}
