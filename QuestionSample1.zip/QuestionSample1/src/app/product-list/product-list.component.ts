import { Component, OnInit } from '@angular/core';
import { ProductListService } from '../product-list.service';
import { ProductList } from '../ProductList';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {

  constructor(private _service:ProductListService) { }
  ProductList:ProductList[];
    ngOnInit() {
      this.getAllProductList();
    }
  getAllProductList(){
  this._service.getAllProductList().subscribe(db=> this.ProductList=db);
  
  
  }
  deleteProduct(i){
    this.ProductList.splice(i,1);
  }
  

}
