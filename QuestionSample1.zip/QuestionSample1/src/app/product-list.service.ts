import { Injectable } from '@angular/core';
// import { HttpClient } from 'selenium-webdriver/http';
import { Observable } from 'rxjs';
import { ProductList } from './ProductList';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class ProductListService {

  constructor(private _http:HttpClient) { }
  url:string='/assets/db.json';
  getAllProductList():Observable<ProductList[]>{
    return this._http.get<ProductList[]>(this.url);
  }
}
