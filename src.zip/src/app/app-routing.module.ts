import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

 import{ CreateAccountComponent } from './create-account/create-account.component';
import{ DepositComponent } from './deposit/deposit.component';
import{ ShowBalanceComponent } from './show-balance/show-balance.component';
import{ WithdrawlComponent } from './withdrawl/withdrawl.component';
import{ FundTransferComponent } from './fund-transfer/fund-transfer.component';
import{ PrintTransactionComponent } from './print-transaction/print-transaction.component';
import{ExitComponent} from './exit/exit.component';

const routes: Routes = [
 
   {path: 'createAccount', component: CreateAccountComponent},
  {path:'showBalance',component:ShowBalanceComponent},
  {path:'deposit',component: DepositComponent},
  {path:'withdrawl',component:WithdrawlComponent},
  {path:'fundTransfer',component:FundTransferComponent},
  {path:'printTransaction',component:PrintTransactionComponent},
  {path:'exit' ,component:ExitComponent}
  
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
