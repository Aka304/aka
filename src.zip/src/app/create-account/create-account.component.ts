import { Component, OnInit } from '@angular/core';
import { AccountService } from '../account.service';
import { Accounts } from '../account';
// import { timingSafeEqual } from 'crypto';


@Component({
  selector: 'app-create-account',
  templateUrl: './create-account.component.html',
  styleUrls: ['./create-account.component.css']
})
export class CreateAccountComponent implements OnInit {
  user: Accounts = new Accounts();
  constructor(private accountService:AccountService) {
    
   }

  ngOnInit() {
  }

  createAccount(data){
    this.user.accntNo=data.accntNo;
    this.user.balance=data.balance;
    this.user.mobileNo=data.mobileNo;
    this.user.name=data.name;
  
this.accountService.createAccount(this.user).subscribe(data=> console.log(data),error=>console.log(error));

}

// export class CreateComponent implements OnInit {
//   user: Customer;
// constructor(private customerService:CustomerServiceService) 
// {  this.user =new Customer();}
   
//   ngOnInit() {
//   }

//   createBankAccount(username,phoneNumber,psw,balance):void {
//     this.user.username=username;
//     this.user.phoneNumber=phoneNumber;
//     this.user.password=psw;
//     this.user.balance=balance;

//     this.customerService.createBankAccount(this.user).subscribe(data => {
//     alert("Account created successfully.");
//     });
// }
}
