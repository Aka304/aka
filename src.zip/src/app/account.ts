export class Accounts {

    name: string;
    accntNo: number;
    mobileNo: string;
    balance : number;
  }