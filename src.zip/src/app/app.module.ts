import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import{FormsModule} from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

 import { CreateAccountComponent } from './create-account/create-account.component';
import { ShowBalanceComponent } from './show-balance/show-balance.component';
import { DepositComponent } from './deposit/deposit.component';
import { PrintTransactionComponent } from './print-transaction/print-transaction.component';
import { ExitComponent } from './exit/exit.component';
import { FundTransferComponent } from './fund-transfer/fund-transfer.component';
import { WithdrawlComponent } from './withdrawl/withdrawl.component';
//  import { ViewComponent } from './view/view.component';
import {HttpClientModule } from '@angular/common/http';
@NgModule({
  declarations: [
    AppComponent,
 
    CreateAccountComponent,
    ShowBalanceComponent,
    DepositComponent,
    PrintTransactionComponent,
    ExitComponent,
    FundTransferComponent,
    WithdrawlComponent,

 
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
