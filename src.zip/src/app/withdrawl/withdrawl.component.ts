import { Component, OnInit } from '@angular/core';
import { AccountService } from '../account.service';
import { Accounts } from '../account';

@Component({
  selector: 'app-withdrawl',
  templateUrl: './withdrawl.component.html',
  styleUrls: ['./withdrawl.component.css']
})
export class WithdrawlComponent implements OnInit {

  amount: Accounts=new Accounts;
  constructor(private accountService:AccountService) { }

  ngOnInit() {
  }

  withdraw(data){
    // this.accountService.depositAmount(accountNum,amount).subscribe(data => {
      
    //     this.amount=this.show.showBalance(accountNum);
    //   }
    //   else{
    //     window.alert('Try Again');
    //   }
    // });
this.amount.accntNo=data.value.accountNum;
this.amount.balance=data.value.amount;
   this.accountService.withdraw(this.amount.accntNo,this.amount.balance).subscribe(data=>this.amount=data);
   }
}
