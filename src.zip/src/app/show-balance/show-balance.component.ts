import { Component, OnInit } from '@angular/core';
import { AccountService } from '../account.service';
import { Subscriber } from '../../../node_modules/rxjs';

@Component({
  selector: 'app-show-balance',
  templateUrl: './show-balance.component.html',
  styleUrls: ['./show-balance.component.css']
})
export class ShowBalanceComponent implements OnInit {
balance:number;
  constructor(private accountService: AccountService) { }

  ngOnInit() {
  }
showBalance(data){
alert("balance");
this.accountService.showBalance(data.accountNum).subscribe(data=>this.balance=data);
}
}


// balance:number;
// constructor(private customerService : CustomerServiceService) { }

// ngOnInit() {
// }
// showBalance(accnum): number
// {
// this.customerService.showBalance(accnum).subscribe(data=>{
// this.balance=data;
// console.log(this.balance);  
// })
// return this.balance;
// }
// }