import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
 
import { Accounts } from './account';
import { Observable } from '../../node_modules/rxjs';



@Injectable({
  providedIn: 'root'
})
export class AccountService {
  

  constructor(private httpClient:HttpClient) { }

  public createAccount(accountForm) {

    return  this.httpClient.post<Accounts>("http://localhost:9091/create", accountForm);

    }
    public showBalance(accountNum): Observable<any>
 {
 //console.log(accountnum);
 return this.httpClient.get<Accounts>("http://localhost:9091/showBalance"+"/" + accountNum);
 }

 public depositAmount(accountNum,amount):Observable<Accounts>{
let url="http://localhost:9091/deposit"+"/"+accountNum+"/"+amount;

return this.httpClient.get<Accounts>(url+"/");

 }
 public withdraw(accountNum,amount):Observable<Accounts>{
  let url="http://localhost:9091/withdraw"+"/"+accountNum+"/"+amount;
  
  return this.httpClient.get<Accounts>(url+"/");
  
   }
}


// public depositAmount(accountnum,amount): Observable<number>
// {
// console.log(accountnum);
// let url = 'http://localhost:9090/user/deposit/'+accountnum+'/'+amount;
// return this.httpClient.put<number>(url,"");
// }
