import { Component, OnInit } from '@angular/core';
import { AccountService } from '../account.service';
import { ShowBalanceComponent } from '../show-balance/show-balance.component';

@Component({
  selector: 'app-fund-transfer',
  templateUrl: './fund-transfer.component.html',
  styleUrls: ['./fund-transfer.component.css']
})
export class FundTransferComponent implements OnInit {

  constructor(private accountService:AccountService,private show: ShowBalanceComponent ) { }

  ngOnInit() {
  }
  cashTransfer(accountNo,recaccountNo,amount){

this.accountService.cashTransfer(accountNo,recaccountNo,amount).subscribe(data=>this.balance)

  }


}
//  cashTransfer(accountNo,recaccountNo,amount)
//  { 
// this.customerService.cashTransfer(accountNo,recaccountNo,amount).subscribe(data => {
// if(data===1)
// {
//   window.alert('Transfer Successful');
//   this.balance=this.show.showBalance(accountNo);
// }
// else{
//   window.alert('Money Not Transferred.Try Again');
// }
//  });
// }
// }
