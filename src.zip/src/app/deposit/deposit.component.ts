import { Component, OnInit } from '@angular/core';
import { AccountService } from '../account.service';
import { ShowBalanceComponent } from '../show-balance/show-balance.component';
import { Accounts } from '../account';

@Component({
  selector: 'app-deposit',
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.css']
})
export class DepositComponent implements OnInit {

  amount: Accounts=new Accounts;
  constructor(private accountService:AccountService) { }

  ngOnInit() {
  }
  depositAmount(data){
    // this.accountService.depositAmount(accountNum,amount).subscribe(data => {
      
    //     this.amount=this.show.showBalance(accountNum);
    //   }
    //   else{
    //     window.alert('Try Again');
    //   }
    // });
this.amount.accntNo=data.value.accountNum;
this.amount.balance=data.value.amount;
   this.accountService.depositAmount(this.amount.accntNo,this.amount.balance).subscribe(data=>this.amount=data);
   }
  }

