package lab9.assignments;

import java.util.HashMap;
import java.util.Scanner;

public class NumAndSq {

	public static void main (String[] args)  {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of elements you want to enter.");
		int size = sc.nextInt();
		int num[] = new int[size];
		for(int i=0; i<size; i++)
			num[i] = sc.nextInt();
		HashMap<Integer,Integer> map = new HashMap<Integer,Integer>();
		map = getSquares(num);
		System.out.println(map);
		sc.close();
	}
	
	static HashMap<Integer, Integer> getSquares(int num[]) {
		HashMap<Integer,Integer> map = new HashMap<Integer, Integer>();
		for(int i=0; i<num.length; i++) {
			map.put(num[i], num[i]*num[i]);
		}
		return map;
		
	}
	
}