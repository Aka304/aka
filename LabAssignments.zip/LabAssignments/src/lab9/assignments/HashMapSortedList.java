package lab9.assignments;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

public class HashMapSortedList {
	
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of values you want to enter in HasMap :");
		int size = sc.nextInt();
		String values ;
		int counter=1;
		HashMap<Integer, String> map = new HashMap<Integer, String>();
		
		// taking the values  from user
		while(counter<=size) {
			System.out.println("Enter value of key "+counter);
			values = sc.next();
			map.put(counter, values);		// adding values in hash map
			counter++;
		}
		HashMapSortedList obj = new HashMapSortedList();
		List<String> list = obj.getValues(map);
		System.out.println(list);
		sc.close();
	}
	
	//add elements into List and sort them

	public List<String> getValues(HashMap<Integer, String> map) {
		List<String> list = new ArrayList<String>();
		int length=map.size();
		for(int i=1; i<=length; i++) {
			list.add(map.get(i));
		}
		list.sort(null);
		return list;
	}
}
