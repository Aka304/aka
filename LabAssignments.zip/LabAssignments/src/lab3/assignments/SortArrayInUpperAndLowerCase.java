package lab3.assignments;

import java.util.Arrays;
import java.util.Scanner;

public class SortArrayInUpperAndLowerCase {
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size of String objects : ");
		int n=sc.nextInt();
		String str[] = new String[n];
		for(int i=0; i<n ; i++) {
			str[i]=sc.next();
		}
		SortArrayInUpperAndLowerCase obj = new SortArrayInUpperAndLowerCase();
		String Arr[] = obj.getSortedArray(str);
		for(int i=0 ; i<n ; i++)
			System.out.println(Arr[i]);
		sc.close();
	}
	
	// method to sort array in upper and lower case
	public String[] getSortedArray(String str[]) {
		
		Arrays.sort(str);
		return str; 
	}
}
