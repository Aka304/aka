package lab3.assignments;

import java.util.Arrays;
import java.util.Scanner;


public class RevNumInArray {
	
	
	
	//method to reverse and sort an array
	public int[] getsorted(int arr[],int n)
	{
		String str;
		String num;
		int y[];
		y=new int[n];
		int a=0;
		for(int i=0;i<n;i++)
		{
			str="";
			num="";
			str=String.valueOf(arr[i]);
		for(int j=str.length()-1;j>=0;j--)
		{
			num=num+str.charAt(j);
		}
		
		num=num.trim();
		y[i]=Integer.parseInt(num);
		}
		Arrays.sort(y);
	return y;
	}
	public static void main(String args[])
	{
		
		int x[];
		int n;
		Scanner s=new Scanner(System.in);
		System.out.println("Enter size of array");
		n=s.nextInt();
		x=new int[n];
		for(int i=0;i<n;i++)
		{
			System.out.println("Enter the number");
			x[i]=s.nextInt();
		}
	RevNumInArray x1=new RevNumInArray();
	x=x1.getsorted(x,n);
	for(int i=0;i<n;i++)
	{
		System.out.println(x[i]);
	}
	}

}

