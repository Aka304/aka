package lab3.assignments;

import java.util.Scanner;




	public class SecondSmallest {
		 
		public int getSecondSmallest(int arr[],int n)
		{
			for(int i=0;i<n;i++)
			{
				for(int j=0;j<n-1;j++)
				if(arr[j]>arr[j+1])
				{
					int temp=arr[j];
					arr[j]=arr[j+1];
					arr[j+1]=temp;
				}	
			}
			for (int i=0;i<n;i++)
			{
				System.out.println(arr[i]);
			}
			return arr[1];
			}

	public static void main(String args[])
	{	 int arr[];
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the size of array");
		int n= s.nextInt();
		arr=new int[n];
		SecondSmallest s1=new SecondSmallest();
		for(int i=0;i<n;i++)
		{
			System.out.println("Enter the element");
			arr[i]=s.nextInt();
		}
		int a=s1.getSecondSmallest(arr, n);
		System.out.println("Second Smallest "+a);
		s.close();
	}
}

