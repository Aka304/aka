package lab5.assignments;

import java.util.Scanner;

public class PrimeNumberRange {

	public static void main(String args[]) {
		int counter=0;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the range for which prime numbers displayed");
		int range = sc.nextInt();
		System.out.println("List of prime numbers from 1 to "+range+" is: ");
		
		// loop to print the list of prime numbers
		for(int i=2;i<=range;i++) {
			for(int j=2 ; j<i ; j++) {
				if(i%j==0)
					counter++;
			}
			if(counter==0)
				System.out.println(i);
			counter=0;
		}
		sc.close();	
	}
}
