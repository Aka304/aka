package Lab11.assignments;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


class CopyDataThread extends Thread {
	
	FileReader inputStream = null;
	FileWriter outputStream = null;
	
	
	public CopyDataThread(FileReader inputStream,FileWriter outputStream) {
		this.inputStream = inputStream;
		this.outputStream = outputStream;
	}
	
	public void run() {
		
		try {
			
			int count=0;
			int c ;
			while((c = inputStream.read())!=-1) {
				count++;
				if(count%10==0) {
					System.out.println("10 characters are copied");
					Thread.sleep(5000);
				}
				outputStream.write(c);
								
			}
			System.out.println("Character Count is:" +count);
			
			if(inputStream!=null) {
				inputStream.close();
			}
			if(outputStream!=null) {
				outputStream.close();
			}
			
		}
		catch(IOException | InterruptedException e) {
			System.out.println(e.getMessage());
		}
		System.out.println("Program End.");		
	}
public static void main(String[] args) throws IOException {
		
		FileReader Source = null;
		FileWriter destination = null;
		
		Source = new FileReader("C:\\Users\\shakchau\\Desktop\\Abc.txt");
		destination = new FileWriter("C:\\Users\\shakchau\\Desktop\\bcd.txt");
		
		ExecutorService service = Executors.newFixedThreadPool(3);
		CopyDataThread thread = new CopyDataThread(Source,destination);
		service.execute(thread);
		service.shutdown();
		
	}

}
