package com.cg.eis.bean;

public class Employee {
	private int eid;
	private String ename;
	private double salary;
	private String scheme;
	private String designation;
	public Employee() {
		// TODO Auto-generated constructor stub
	}
	public Employee(int eid, String ename, double salary, String designation) {
		
		this.eid = eid;
		this.ename = ename;
		this.salary = salary;
		this.designation = designation;
	}
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public String getScheme() {
		return scheme;
	}
	public void setScheme(String scheme) {
		this.scheme = scheme;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	@Override
	public String toString() {
		return "EmployeeDao [eid=" + eid + ", ename=" + ename + ", salary=" + salary + ", scheme=" + scheme
				+ ", designation=" + designation + "]";
	}
	public void printDetails() {
		System.out.println("Emp ID is:"+eid);
		System.out.println("Emp name is:"+ename);
		System.out.println("Emp salary is:"+salary);
	}
}
