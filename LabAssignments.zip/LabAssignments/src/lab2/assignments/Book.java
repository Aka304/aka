package lab2.assignments;

public  class Book extends WrittenItem {
	public Book()
	{
		System.out.println("This is a book");
		setAuthor("shakti");
		setId(10);
		setTitle("python");
		setNoc(4);
		show();
	}
	
	public void show(){
		System.out.println("Book Name="+getTitle());
		System.out.println("Book ID="+getId());
		System.out.println("Book Copies Available="+getNoc());
		System.out.println("book Author="+getAuthor());
	}
	
}
