package lab8.assignments;


import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;


public class ReadFile {

	BufferedReader br;
	public static void main(String[] args) throws IOException {
		ReadFile readFile = new ReadFile();
		Scanner sc = new Scanner(System.in);
		String file = sc.nextLine();
		readFile.getFileContents(file);
		sc.close();
	}
		public void getFileContents(String file) {
			System.out.println("File Name\t:\t"+file+"\n");
			String line=null;
			try {
				FileReader fr=new FileReader(file);
				BufferedReader br= new BufferedReader(fr);
				int count=1;
				while((line=br.readLine())!=null) {
					System.out.println(count+" "+line);
					count++;
				}
				br.close();
			}
			catch(IOException e) {
				System.out.println("Error in reading file.");
			}
		}
}
