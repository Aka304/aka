package lab8.assignments;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class DetailsOfJobseekers {

	public static void main(String[] args) throws IOException {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the name");
		String name=br.readLine();
		DetailsOfJobseekers obj=new DetailsOfJobseekers();
		boolean result = obj.nameValidation(name);
		if(result)
			System.out.println("valid");
		else
			System.out.println("Invalid");
	}

	private boolean nameValidation(String username) {
		if((username.length()>=5)&&(username.indexOf("_job")>=4))
			return true;
		else
			return false;
	}
}
