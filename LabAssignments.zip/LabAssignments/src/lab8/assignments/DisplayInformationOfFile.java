package lab8.assignments;

import java.io.File;
import java.util.Scanner;

public class DisplayInformationOfFile {

	public static void main(String[] args){
		String path;
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the name of the file:");
		path=s.nextLine();
		File f1 = new File(path);
		
		//check whether the given file exists or not
		if(f1.exists()) {
			System.out.println("The file " +f1.getName()+ " exists");
			
			//check if the given file is readable or not
			if(f1.canRead())
				System.out.println("The file " +f1.getName()+" is readable");
			else
				System.out.println("The file " +f1.getName() +" is not readable");
			
			//check if you can write 
			if(f1.canWrite())
				System.out.println("The file " +f1.getName()+ " is writeable");
			else
				System.out.println("The file " +f1.getName()+ " is not writeable");
		}
		else
			System.out.println("The file " +f1.getName()+ " does not exist");
		System.out.println("The file type is: " +f1.getName().substring(f1.getName().indexOf('.')+1));
		System.out.println("The Length of the file:" +f1.length());
	}
}
