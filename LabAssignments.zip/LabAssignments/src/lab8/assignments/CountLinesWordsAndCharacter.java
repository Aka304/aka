package lab8.assignments;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;

public class CountLinesWordsAndCharacter {
		   
	public static void main(String args[]) throws Exception
	{
		FileInputStream f=new FileInputStream("C:\\Users\\shakchau\\Desktop\\project\\LabAssignments\\src\\abc.txt");
		int character=0;
		int word=0;
		int line=1;
		int i=f.read(); 
		while(i!=-1)
		{
			if(i!=10&&i!=32)
			{
				character++;
			}
			if(i==10||i==32)
			{
				word++;
			}
			if(i==10)
			{
				line++;
			}
			i=f.read();
		}
		f.close();
		System.out.println("Character in file="+character);
		System.out.println("Word in file="+word);
		System.out.println("Line in file"+line);
	}
}
